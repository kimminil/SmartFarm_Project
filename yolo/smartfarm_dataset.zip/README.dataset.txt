# smartfarm > test1
https://universe.roboflow.com/test-ua6ez/smartfarm-ytvsq

Provided by a Roboflow user
License: MIT

